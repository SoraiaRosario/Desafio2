﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient; //Adicionado
using System.Configuration; //Adicionado
using System.Data; //Adicionado

public partial class BackOffice_SeeUsers : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {

            if (Session["SessaoAdministrador"] != null)
            {
                Label1.Text += Session["SessaoAdministrador"].ToString();
                //Label2.Text += Session["SessaoAdministradorID"].ToString();
            }
            else
            {
                Response.Redirect("BackLogin.aspx");
            }
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {

    }

    protected void Button1_Click1(object sender, EventArgs e)
    {
        FormView1.ChangeMode(FormViewMode.Insert); // 
    }

    protected void FormView1_ItemDeleted(object sender, FormViewDeletedEventArgs e)
    {
        GridView1.DataBind(); //Quando alterada a formview aparece na gridview
    }

    protected void FormView1_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        GridView1.DataBind();
    }

    protected void FormView1_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
    {
        GridView1.DataBind();
    }

    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Session["SessaoAdministrador"] = null;
        Response.Redirect("BackLogin.aspx");
    }

}